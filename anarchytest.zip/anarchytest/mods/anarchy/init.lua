minetest.register_item(":", {
	type = "none",
	wield_image = "pick.png",
	wield_scale = {x=1,y=1,z=2.5},
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level = 0,
		groupcaps = {
			crumbly = {times={[2]=3.00, [3]=0.70}, uses=0, maxlevel=1},
			snappy = {times={[3]=0.40}, uses=0, maxlevel=1},
			oddly_breakable_by_hand = {times={[1]=3.50,[2]=2.00,[3]=0.70}, uses=0}
		},
		damage_groups = {fleshy=1},
	}
})

function makenode(name)
	minetest.register_node("anarchy:"..name, {
		description = name,
		tiles = {name..".png"},
		groups = {crumbly = 3},
		paramtype = "light",
		sunlight_propagates = true,
		light_source = 5
	})
	minetest.register_craft({
		type="shapeless",
		output="anarchy:"..name,
		recipe={"anarchy:"..name,"anarchy:"..name}
	})
end
function makefood(name)
	minetest.register_node("anarchy:"..name, {
		description = name,
		tiles = {name..".png"},
		groups = {crumbly = 3},
		paramtype = "light",
		sunlight_propagates = true,
		light_source = 5,
		on_use = minetest.item_eat(2)
	})
	minetest.register_craft({
		type="shapeless",
		output="anarchy:"..name,
		recipe={"anarchy:"..name,"anarchy:"..name}
	})
end

makenode("grey")
makenode("brown")
makenode("green")
makenode("yellow")
makenode("blue")
makenode("cyan")
makefood("red")
makenode("black")
makenode("orange")
makenode("white")
makenode("purple")
makenode("pink")

minetest.register_alias("mapgen_stone", "anarchy:grey")
minetest.register_alias("mapgen_dirt", "anarchy:brown")
minetest.register_alias("mapgen_dirt_with_grass", "anarchy:green")
minetest.register_alias("mapgen_sand", "anarchy:yellow")
minetest.register_alias("mapgen_water_source", "anarchy:blue")
minetest.register_alias("mapgen_river_water_source", "anarchy:cyan")
minetest.register_alias("mapgen_lava_source", "anarchy:red")
minetest.register_alias("mapgen_gravel", "anarchy:black")
minetest.register_alias("mapgen_desert_stone", "anarchy:grey")
minetest.register_alias("mapgen_desert_sand", "anarchy:orange")
minetest.register_alias("mapgen_dirt_with_snow", "anarchy:white")
minetest.register_alias("mapgen_snowblock", "anarchy:white")
minetest.register_alias("mapgen_snow", "air")
minetest.register_alias("mapgen_ice", "anarchy:cyan")
minetest.register_alias("mapgen_sandstone", "anarchy:yellow")
minetest.register_alias("mapgen_tree", "anarchy:brown")
minetest.register_alias("mapgen_leaves", "anarchy:green")
minetest.register_alias("mapgen_apple", "anarchy:red")
minetest.register_alias("mapgen_jungletree", "anarchy:brown")
minetest.register_alias("mapgen_jungleleaves", "anarchy:purple")
minetest.register_alias("mapgen_junglegrass", "air")
minetest.register_alias("mapgen_pine_tree", "anarchy:brown")
minetest.register_alias("mapgen_pine_needles", "anarchy:pink")
minetest.register_alias("mapgen_cobble", "anarchy:grey")
minetest.register_alias("mapgen_stair_cobble", "air")
minetest.register_alias("mapgen_mossycobble", "anarchy:green")
minetest.register_alias("mapgen_stair_desert_stone", "air")
minetest.register_alias("mapgen_sandstonebrick", "anarchy:yellow")
minetest.register_alias("mapgen_stair_sandstone_block", "air")
