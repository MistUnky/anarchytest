==== Nuke Mod for Minetest ===
Version 2.2

License of mod code and textures:
MIT

License of sounds:
- nuke_explode.ogg: Jose Ortiz 'MindChamber' (CC0)
- nuke_ignite.ogg: Wuzzy's derivative work of a sound by Ned Bouhalassa (CC0)
	<https://freesound.org/people/Ned%20Bouhalassa/sounds/8320/>
