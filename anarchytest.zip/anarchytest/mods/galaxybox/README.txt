Galaxy Skybox
Version 1.0.0

A mod for Minetest.

This mod adds a simple skybox showing a galaxy.


License of skybox textures:
CC-BY and CC-BY-SA - From hackcraft.de <http://hackcraft.de/>.

License of everything else: WTFPL
